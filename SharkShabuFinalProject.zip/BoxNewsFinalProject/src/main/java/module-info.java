module com.example.boxnewsfinalproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.desktop;

    opens com.example.boxnewsfinalproject to javafx.fxml;
    exports com.example.boxnewsfinalproject;
}